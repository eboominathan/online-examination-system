---WWW.ALPHACODECAMP.COM.NG---

INSTALLATION GUIDE

1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR VS CODE / ETC.

3.Folder name:
     "Online Examination System"

4. Download the zip file/ download din ng winrar

5. Extract the file and copy "Online Examination System" folder

6.Paste inside root directory/xampp/htdocs.

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name oes_db

6. Import oes_db.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Online-examination-system/


admin
url:http://localhost/Online-examination-system/adminpanel/admin/
Username: admin@mail.com
Password: alphacodecamp

user
url: http://localhost/Online-examination-system/
Username:sam@mail.com
Password:sam
